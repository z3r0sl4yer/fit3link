# Galaxy Fit3 + iPhone 14 Pro

Este repositório contém a estrutura necessária para testar e conectar o seu **iPhone 14 Pro** ao **Samsung Galaxy Fit3**.

---

## ⚠️ Ponto Fundamental: Windows vs iPhone (iOS)

A Apple exige o sistema **macOS com Xcode** para compilar e instalar um aplicativo nativo Swift diretamente no iPhone via cabo USB. O Windows não possui o compilador nativo da Apple.

Por isso, preparamos duas soluções já prontas nesta pasta:

---

## Solução 1: Teste Imediato no iPhone (Sem precisar de Mac)

Para testar a comunicação BLE imediatamente no seu iPhone sem precisar compilar código:

1. No seu iPhone 14 Pro, abra a **App Store** e baixe o aplicativo gratuito chamado **Bluefy - Web BLE Browser** (navegador que dá suporte a Bluetooth no iOS).
2. Abra o arquivo `web_ble_tester.html` (você pode enviá-lo para o seu iPhone via AirDrop/iCloud Drive/WhatsApp ou abri-lo localmente).
3. Toque no botão **"Escanear & Conectar Fit3"**.
4. Selecione o seu Galaxy Fit3 na lista.
5. O aplicativo irá se conectar à pulseira e listar todos os **Serviços GATT** e **Características** suportadas em tempo real!

---

## Solução 2: Aplicativo Nativo Swift / SwiftUI (`GalaxyFit3Link`)

Se você tiver acesso a um Mac (ou quiser compilar via GitHub Actions / Xcode Cloud):

- `GalaxyFit3LinkApp.swift`: Ponto de entrada do aplicativo iOS.
- `ContentView.swift`: Interface gráfica em SwiftUI com lista de dispositivos, logs e visualização dos serviços.
- `BluetoothManager.swift`: Gerenciador `CoreBluetooth` configurado com `CBCentralManager` e `CBPeripheralDelegate`.
- `Info.plist`: Contém as permissões necessárias (`NSBluetoothAlwaysUsageDescription` e `bluetooth-central`).

### Como rodar no Mac:
1. Abra o Xcode no Mac e crie um novo projeto iOS SwiftUI chamado `GalaxyFit3Link`.
2. Arraste os arquivos da pasta `GalaxyFit3Link` para dentro do projeto.
3. Conecte o iPhone 14 Pro via cabo USB, selecione-o como destino e clique em **Run** (Play).
